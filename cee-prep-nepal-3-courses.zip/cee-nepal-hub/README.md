# CEE Nepal Hub 🇳🇵

Multi-course CEE preparation platform for Nepal entrance aspirants.

## Courses
- 🐾 BVSc & AH
- 🌾 Agriculture
- 🌲 Forestry

## Features
- Course selection
- Subject-wise chapter practice
- MCQs with explanations
- Difficulty filters
- Timed mock tests with negative marking
- Saved/bookmarked questions
- Revision notes
- Performance dashboard
- Dark mode
- Mobile-friendly interface

## Run locally
```bash
npm install
npm run dev
```

## Important
This is an independent preparation platform. The included question bank is a starter/sample bank and should be expanded and verified against the current official entrance syllabus before public launch.
