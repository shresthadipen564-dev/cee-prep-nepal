# CEE Nepal Hub — VetCEE

Nepal-focused entrance preparation website starter.

## Brand
- Main platform: **CEE Nepal Hub**
- First module: **VetCEE — BVSc & AH**
- Architecture already separates courses so Agriculture and Forestry can be added later.

## Included upgrades
- Fixed answer/scoring logic
- Chapter practice
- Difficulty filters
- Full mock test with timer
- Negative marking in mock test
- Saved/bookmarked questions
- Searchable chapter selection
- High-yield notes
- Performance dashboard
- Persistent localStorage data
- Dark mode
- Responsive mobile navigation
- Disclaimer/independent-platform branding

## Run
```bash
npm install
npm run dev
```

Then open the local Vite URL shown in the terminal.

## Important
The question bank included here is a starter/sample bank. Before public launch, replace/expand it with verified BVSc CEE-aligned questions and officially sourced syllabus information.
