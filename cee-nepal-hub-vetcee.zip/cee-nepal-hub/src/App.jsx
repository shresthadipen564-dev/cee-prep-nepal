import React, { useEffect, useMemo, useState } from "react";
import {
  Award, BarChart3, Bookmark, BookOpen, CheckCircle2, ChevronRight,
  Clock3, Filter, Flag, HelpCircle, Home, Menu, Moon, PenTool,
  RotateCcw, Search, Settings2, ShieldCheck, Star, Sun, Trophy, X,
  XCircle
} from "lucide-react";

/* =========================================================
   CEE NEPAL HUB — VetCEE
   Improvements over the original:
   - safer scoring: answers are tracked per question
   - no score inflation when going back/re-answering
   - mock-test mode with timer + negative marking
   - search/filter in question bank
   - bookmarks persist
   - stats persist
   - dark mode persists
   - course architecture supports BVSc now and Agriculture/Forestry later
   - mobile navigation
   - error-safe localStorage helpers
   ========================================================= */

const BRAND = {
  name: "CEE Nepal Hub",
  module: "VetCEE",
  tagline: "Nepal Entrance Preparation"
};

const COURSES = [
  { id: "bvsc", name: "BVSc & AH", icon: "🐾", active: true },
  { id: "agri", name: "Agriculture", icon: "🌾", active: false },
  { id: "forestry", name: "Forestry", icon: "🌲", active: false }
];

const SYLLABUS = {
  bio: ["Cell Biology","Biomolecules","Genetics","Evolution","Animal Diversity","Animal Tissues","Human Physiology","Reproduction","Ecology","Plant Anatomy","Plant Physiology","Plant Reproduction","Taxonomy","Microbiology","Biotechnology"],
  chem: ["Atomic Structure","Periodic Table","Chemical Bonding","States of Matter","Thermodynamics","Equilibrium","Redox Reactions","Organic Chemistry","Hydrocarbons","Alcohols, Phenols and Ethers","Aldehydes and Ketones","Biomolecules","Environmental Chemistry"],
  phys: ["Units and Dimensions","Vectors","Kinematics","Laws of Motion","Work, Energy and Power","Gravitation","Properties of Matter","Heat and Thermodynamics","Oscillation","Waves","Optics","Electrostatics","Current Electricity","Magnetism","Electromagnetic Induction","Modern Physics","Nuclear Physics"]
};

const MCQS = [
  {id:1,subject:"bio",chapter:"Cell Biology",difficulty:"Easy",question:"Which organelle is known as the 'Suicidal Bag' of the cell?",options:["Ribosome","Lysosome","Mitochondria","Vacuole"],correct:1,explanation:"Lysosomes contain hydrolytic enzymes and are associated with intracellular digestion."},
  {id:2,subject:"bio",chapter:"Genetics",difficulty:"Medium",question:"A cross between an individual of unknown dominant genotype and a homozygous recessive individual is called:",options:["Back cross","Test cross","Reciprocal cross","Dihybrid cross"],correct:1,explanation:"A test cross uses a homozygous recessive individual to reveal the genotype of the unknown dominant phenotype."},
  {id:3,subject:"bio",chapter:"Human Physiology",difficulty:"Hard",question:"Which hormone is primarily responsible for the 'fight or flight' response?",options:["Thyroxine","Insulin","Adrenaline","Estrogen"],correct:2,explanation:"Adrenaline (epinephrine) is released from the adrenal medulla during acute stress."},
  {id:4,subject:"bio",chapter:"Animal Diversity",difficulty:"Medium",question:"The characteristic respiratory organ found in most aquatic molluscs is:",options:["Book lungs","Ctenidia","Trachea","Air sacs"],correct:1,explanation:"Ctenidia are gill-like respiratory structures characteristic of many molluscs."},
  {id:5,subject:"bio",chapter:"Taxonomy",difficulty:"Easy",question:"The five-kingdom classification was proposed by:",options:["Linnaeus","R.H. Whittaker","Aristotle","Darwin"],correct:1,explanation:"R.H. Whittaker proposed the five-kingdom classification in 1969."},
  {id:6,subject:"bio",chapter:"Plant Physiology",difficulty:"Medium",question:"Which pigment is the primary photosynthetic pigment directly involved in the reaction centres?",options:["Chlorophyll a","Chlorophyll b","Carotene","Xanthophyll"],correct:0,explanation:"Chlorophyll a is the primary photosynthetic pigment in oxygenic photosynthesis."},
  {id:7,subject:"bio",chapter:"Microbiology",difficulty:"Hard",question:"The protein coat surrounding viral genetic material is called:",options:["Nucleoid","Capsid","Capsomere","Envelope"],correct:1,explanation:"The capsid is the protein shell surrounding the viral genome; capsomeres are its subunits."},
  {id:8,subject:"bio",chapter:"Cell Biology",difficulty:"Medium",question:"During which stage of mitosis do chromosomes align at the equator?",options:["Prophase","Metaphase","Anaphase","Telophase"],correct:1,explanation:"Chromosomes align at the metaphase plate during metaphase."},
  {id:9,subject:"bio",chapter:"Ecology",difficulty:"Easy",question:"The pyramid of energy is always:",options:["Inverted","Upright","Spindle-shaped","Horizontal"],correct:1,explanation:"Energy decreases at successive trophic levels, so the energy pyramid is always upright."},
  {id:10,subject:"bio",chapter:"Reproduction",difficulty:"Medium",question:"Double fertilization is a characteristic feature of:",options:["Algae","Bryophytes","Gymnosperms","Angiosperms"],correct:3,explanation:"Angiosperms show syngamy and triple fusion, collectively called double fertilization."},
  {id:21,subject:"chem",chapter:"Atomic Structure",difficulty:"Easy",question:"The shape of an s orbital is:",options:["Spherical","Dumbbell","Double dumbbell","Linear"],correct:0,explanation:"An s orbital has spherical symmetry around the nucleus."},
  {id:22,subject:"chem",chapter:"Organic Chemistry",difficulty:"Hard",question:"Which is the strongest acid among the following?",options:["CH3COOH","ClCH2COOH","Cl2CHCOOH","Cl3CCOOH"],correct:3,explanation:"The electron-withdrawing inductive effect of three chlorine atoms strongly stabilizes the conjugate base."},
  {id:23,subject:"chem",chapter:"Chemical Bonding",difficulty:"Medium",question:"The approximate bond angle in an ideal sp3-hybridized molecule is:",options:["90°","109.5°","120°","180°"],correct:1,explanation:"Four sp3 hybrid orbitals arrange tetrahedrally with an ideal angle of about 109.5°."},
  {id:24,subject:"chem",chapter:"Periodic Table",difficulty:"Easy",question:"Across a period, atomic radius generally:",options:["Increases","Decreases","Remains constant","First doubles"],correct:1,explanation:"Effective nuclear charge generally increases across a period, pulling electrons closer."},
  {id:41,subject:"phys",chapter:"Units and Dimensions",difficulty:"Easy",question:"The dimensional formula for power is:",options:["ML²T⁻²","ML²T⁻³","MLT⁻²","M⁰L⁰T⁰"],correct:1,explanation:"Power = work/time = ML²T⁻²/T = ML²T⁻³."},
  {id:42,subject:"phys",chapter:"Optics",difficulty:"Medium",question:"A concave mirror produces a virtual, erect and magnified image when the object is placed:",options:["At C","Between C and F","Between F and P","Beyond C"],correct:2,explanation:"An object placed between the pole and focus of a concave mirror produces a virtual, erect and magnified image."},
  {id:43,subject:"phys",chapter:"Kinematics",difficulty:"Easy",question:"The slope of a velocity-time graph represents:",options:["Displacement","Velocity","Acceleration","Momentum"],correct:2,explanation:"Acceleration is the rate of change of velocity, represented by the slope of a v-t graph."},
  {id:44,subject:"phys",chapter:"Oscillation",difficulty:"Medium",question:"For a simple pendulum at small amplitude, its time period is proportional to:",options:["√l","1/√l","l","1/l"],correct:0,explanation:"T = 2π√(l/g), so T is proportional to √l for constant g."}
];

const NOTES = {
  bio: [
    {title:"Genetics Revision",points:["Law of segregation separates alleles during gamete formation.","Incomplete dominance may produce a 1:2:1 phenotypic ratio.","Hemophilia is an X-linked recessive trait."],trap:"Test cross is a specific type of back cross, but not every back cross is a test cross."},
    {title:"Cell Biology Facts",points:["Mitochondria and chloroplasts are semi-autonomous organelles.","70S ribosomes occur in prokaryotes and in mitochondria/chloroplasts.","Singer and Nicolson proposed the fluid mosaic model."],trap:"The plasma membrane is selectively permeable, not freely permeable."}
  ],
  chem: [
    {title:"Chemical Bonding",points:["Sigma bonds are generally stronger than pi bonds.","sp3 hybridization has an ideal angle of 109.5°.","Hydrogen bonding can strongly affect boiling points and solubility."],trap:"Ionic solids do not conduct electricity well in the solid state because ions are not free to move."},
    {title:"Organic Rules",points:["Markovnikov orientation applies to many HX additions to unsymmetrical alkenes.","Ozonolysis of alkenes can yield carbonyl compounds.","Lucas reagent helps distinguish alcohol classes by reaction rate."],trap:"Phenol is more acidic than ordinary alcohols because phenoxide is resonance-stabilized."}
  ],
  phys: [
    {title:"Kinematics Quick",points:["Slope of a v-t graph gives acceleration.","For ideal projectile motion, range is maximum at 45° on level ground.","Relative velocity of A with respect to B is vA − vB."],formula:"v² = u² + 2as    |    s = ut + ½at²"},
    {title:"Optics Summary",points:["Snell's law: n1 sinθ1 = n2 sinθ2.","Lens power P = 1/f when f is in metres.","Total internal reflection requires light to travel from denser to rarer medium at an angle above the critical angle."],trap:"During refraction, frequency remains unchanged; speed and wavelength change."}
  ]
};

const STORAGE = {
  bookmarks:"cee_nepal_bookmarks_v3",
  stats:"cee_nepal_stats_v3",
  theme:"cee_nepal_theme_v3"
};

function readJSON(key, fallback) {
  try { return JSON.parse(localStorage.getItem(key)) ?? fallback; }
  catch { return fallback; }
}

const DEFAULT_STATS = {
  attempted:0, correct:0, sessions:0,
  byDifficulty:{Easy:0,Medium:0,Hard:0},
  lastScores:[],
  bestScore:0
};

function App() {
  const [page,setPage] = useState("home");
  const [course,setCourse] = useState("bvsc");
  const [subject,setSubject] = useState("bio");
  const [chapter,setChapter] = useState(null);
  const [difficulty,setDifficulty] = useState("All");
  const [bookmarks,setBookmarks] = useState(() => readJSON(STORAGE.bookmarks, []));
  const [stats,setStats] = useState(() => ({...DEFAULT_STATS,...readJSON(STORAGE.stats,{})}));
  const [dark,setDark] = useState(() => readJSON(STORAGE.theme,false));
  const [mobileOpen,setMobileOpen] = useState(false);

  useEffect(()=>localStorage.setItem(STORAGE.bookmarks,JSON.stringify(bookmarks)),[bookmarks]);
  useEffect(()=>localStorage.setItem(STORAGE.stats,JSON.stringify(stats)),[stats]);
  useEffect(()=>localStorage.setItem(STORAGE.theme,JSON.stringify(dark)),[dark]);

  const nav = p => { setPage(p); setMobileOpen(false); window.scrollTo({top:0,behavior:"smooth"}); };
  const toggleBookmark = id => setBookmarks(prev => prev.includes(id) ? prev.filter(x=>x!==id) : [...prev,id]);

  const startChapter = (sub,chap) => {
    setSubject(sub); setChapter(chap); setDifficulty("All"); nav("practice");
  };

  const finishPractice = result => {
    setStats(prev => ({
      ...prev,
      attempted:prev.attempted + result.total,
      correct:prev.correct + result.score,
      sessions:prev.sessions + 1,
      bestScore:Math.max(prev.bestScore,result.percent),
      lastScores:[result.percent,...prev.lastScores].slice(0,5),
      byDifficulty:{
        ...prev.byDifficulty,
        ...Object.fromEntries(Object.entries(result.byDifficulty).map(([k,v])=>[k,(prev.byDifficulty[k]||0)+v]))
      }
    }));
    nav("dashboard");
  };

  const shell = (
    <div className={dark ? "app dark" : "app"}>
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-icon"><Award size={24}/></div>
          <div><strong>{BRAND.name}</strong><small>{BRAND.module} • Nepal</small></div>
        </div>
        <nav>
          <NavItem icon={<Home/>} text="Home" active={page==="home"} onClick={()=>nav("home")}/>
          <NavItem icon={<PenTool/>} text="Practice" active={["practice","select"].includes(page)} onClick={()=>nav("select")}/>
          <NavItem icon={<Trophy/>} text="Mock Test" active={page==="mock"} onClick={()=>nav("mock")}/>
          <NavItem icon={<Bookmark/>} text="Saved Questions" active={page==="saved"} onClick={()=>nav("saved")}/>
          <NavItem icon={<BookOpen/>} text="Revision Notes" active={page==="notes"} onClick={()=>nav("notes")}/>
          <NavItem icon={<BarChart3/>} text="Performance" active={page==="dashboard"} onClick={()=>nav("dashboard")}/>
        </nav>
        <div className="sidebar-bottom">
          <button className="theme-btn" onClick={()=>setDark(v=>!v)}>{dark?<Sun size={18}/>:<Moon size={18}/>} {dark?"Light mode":"Dark mode"}</button>
          <div className="disclaimer-mini"><ShieldCheck size={16}/><span>Independent preparation platform</span></div>
        </div>
      </aside>

      <header className="mobile-header">
        <button onClick={()=>setMobileOpen(v=>!v)}><Menu/></button>
        <div><strong>{BRAND.name}</strong><span>{BRAND.module}</span></div>
        <button onClick={()=>setDark(v=>!v)}>{dark?<Sun/>:<Moon/>}</button>
      </header>

      {mobileOpen && <div className="mobile-menu">
        {[
          ["home","Home",Home],["select","Practice",PenTool],["mock","Mock Test",Trophy],
          ["saved","Saved",Bookmark],["notes","Notes",BookOpen],["dashboard","Performance",BarChart3]
        ].map(([p,t,I])=><NavItem key={p} icon={<I/>} text={t} active={page===p} onClick={()=>nav(p)}/>)}
      </div>}

      <main className="main">
        {page==="home" && <HomePage stats={stats} nav={nav} start={startChapter} course={course} setCourse={setCourse}/>}
        {page==="select" && <Selection onSelect={startChapter} course={course}/>}
        {page==="practice" && <Practice subject={subject} chapter={chapter} difficulty={difficulty} setDifficulty={setDifficulty} bookmarks={bookmarks} toggleBookmark={toggleBookmark} onFinish={finishPractice}/>}
        {page==="mock" && <MockTest bookmarks={bookmarks} toggleBookmark={toggleBookmark} onFinish={finishPractice}/>}
        {page==="saved" && <Saved bookmarks={bookmarks} toggleBookmark={toggleBookmark}/>}
        {page==="notes" && <Notes/>}
        {page==="dashboard" && <Dashboard stats={stats}/>}
      </main>
    </div>
  );
  return shell;
}

function NavItem({icon,text,active,onClick}) {
  return <button className={active?"nav-item active":"nav-item"} onClick={onClick}>{React.cloneElement(icon,{size:19})}<span>{text}</span></button>;
}

function HomePage({stats,nav,start,course,setCourse}) {
  return <div className="page enter">
    <section className="hero">
      <div>
        <div className="eyebrow">🇳🇵 Nepal Entrance Preparation</div>
        <h1>Target your <span>CEE</span> with confidence.</h1>
        <p>Chapter-wise MCQs, high-yield revision, mock tests and performance tracking — built for Nepal's entrance aspirants.</p>
        <div className="hero-actions">
          <button className="primary" onClick={()=>nav("select")}>Start Practice <ChevronRight size={18}/></button>
          <button className="secondary" onClick={()=>nav("mock")}>Full Mock Test</button>
        </div>
      </div>
      <div className="hero-badge"><Award size={56}/><strong>VetCEE</strong><small>BVSc & AH</small></div>
    </section>

    <section className="course-strip">
      {COURSES.map(c=><button key={c.id} disabled={!c.active} className={course===c.id?"course-card selected":"course-card"} onClick={()=>c.active&&setCourse(c.id)}>
        <span>{c.icon}</span><div><strong>{c.name}</strong><small>{c.active?"Available now":"Coming soon"}</small></div>
      </button>)}
    </section>

    <div className="stats-grid">
      <Stat label="Questions Attempted" value={stats.attempted}/>
      <Stat label="Accuracy" value={`${stats.attempted?Math.round(stats.correct/stats.attempted*100):0}%`}/>
      <Stat label="Best Session" value={`${stats.bestScore||0}%`}/>
      <Stat label="Sessions" value={stats.sessions}/>
    </div>

    <div className="section-head"><div><div className="eyebrow">Choose a subject</div><h2>Practice by subject</h2></div><button className="text-btn" onClick={()=>nav("select")}>View syllabus <ChevronRight size={16}/></button></div>
    <div className="subject-grid">
      {[
        ["bio","🌿","Biology"],["chem","🧪","Chemistry"],["phys","⚛️","Physics"]
      ].map(([s,emoji,name])=><button className="subject-card" key={s} onClick={()=>{setCourse; start(s,SYLLABUS[s][0])}}>
        <span className="subject-icon">{emoji}</span><div><strong>{name}</strong><small>{SYLLABUS[s].length} chapters</small></div><ChevronRight/>
      </button>)}
    </div>

    <section className="trust-card">
      <ShieldCheck size={22}/><div><strong>Independent educational platform</strong><p>CEE Nepal Hub is not affiliated with MEC, TU, AFU or any government body. Content is for preparation only.</p></div>
    </section>
  </div>;
}

function Selection({onSelect}) {
  const [sub,setSub]=useState("bio");
  const [query,setQuery]=useState("");
  const chapters=SYLLABUS[sub].filter(c=>c.toLowerCase().includes(query.toLowerCase()));
  return <div className="page enter">
    <div className="page-title"><div><div className="eyebrow">Syllabus</div><h1>Choose your chapter</h1></div><div className="search"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search chapter..."/></div></div>
    <div className="tabs">{["bio","chem","phys"].map(s=><button key={s} className={sub===s?"tab active":"tab"} onClick={()=>setSub(s)}>{s==="bio"?"Biology":s==="chem"?"Chemistry":"Physics"}</button>)}</div>
    <div className="chapter-grid">
      {chapters.map(ch=><button key={ch} className="chapter-card" onClick={()=>onSelect(sub,ch)}>
        <div><strong>{ch}</strong><small>{MCQS.filter(q=>q.subject===sub&&q.chapter===ch).length} available questions</small></div><ChevronRight/>
      </button>)}
    </div>
  </div>;
}

function Practice({subject,chapter,difficulty,setDifficulty,bookmarks,toggleBookmark,onFinish}) {
  const questions=useMemo(()=>MCQS.filter(q=>q.subject===subject&&q.chapter===chapter&&(difficulty==="All"||q.difficulty===difficulty)),[subject,chapter,difficulty]);
  const [idx,setIdx]=useState(0);
  const [answers,setAnswers]=useState({});
  const [showExpl,setShowExpl]=useState(false);

  useEffect(()=>{setIdx(0);setAnswers({});setShowExpl(false)},[subject,chapter,difficulty]);

  if(!questions.length) return <Empty chapter={chapter} reset={()=>setDifficulty("All")}/>;

  const q=questions[idx];
  const selected=answers[q.id];
  const answered=selected!==undefined;
  const score=questions.reduce((n,x)=>n+(answers[x.id]===x.correct?1:0),0);

  const answer=i=>{
    if(answered)return;
    setAnswers(a=>({...a,[q.id]:i}));
    setShowExpl(true);
  };

  const finish=()=>{
    const byDifficulty={Easy:0,Medium:0,Hard:0};
    questions.forEach(x=>{byDifficulty[x.difficulty]=(byDifficulty[x.difficulty]||0)+1});
    onFinish({score,total:questions.length,percent:Math.round(score/questions.length*100),byDifficulty});
  };

  return <div className="page narrow enter">
    <div className="practice-top">
      <div><span className="pill">{chapter}</span><h1>Question {idx+1}<em> / {questions.length}</em></h1></div>
      <div className="difficulty-row">{["All","Easy","Medium","Hard"].map(d=><button key={d} onClick={()=>setDifficulty(d)} className={difficulty===d?"mini active":"mini"}>{d}</button>)}</div>
    </div>
    <div className="progress"><span style={{width:`${((idx+1)/questions.length)*100}%`}}/></div>

    <div className="question-card">
      <button className={bookmarks.includes(q.id)?"bookmark saved":"bookmark"} onClick={()=>toggleBookmark(q.id)}><Star size={20} fill={bookmarks.includes(q.id)?"currentColor":"none"}/></button>
      <span className={`level ${q.difficulty.toLowerCase()}`}>{q.difficulty}</span>
      <h2>{q.question}</h2>
      <div className="options">{q.options.map((opt,i)=>{
        let cls="option";
        if(answered&&i===q.correct)cls+=" correct";
        else if(answered&&i===selected)cls+=" wrong";
        return <button key={opt} disabled={answered} className={cls} onClick={()=>answer(i)}><span>{String.fromCharCode(65+i)}</span><b>{opt}</b>{answered&&i===q.correct&&<CheckCircle2/>}{answered&&i===selected&&i!==q.correct&&<XCircle/>}</button>
      })}</div>
      {showExpl&&<div className="explanation"><HelpCircle/><div><strong>Concept Check</strong><p>{q.explanation}</p></div></div>}
    </div>
    <div className="practice-actions">
      <button className="secondary wide" disabled={idx===0} onClick={()=>{setIdx(i=>i-1);setShowExpl(false)}}>Previous</button>
      {idx===questions.length-1
        ? <button className="primary wide" disabled={!answered} onClick={finish}>Finish • {score}/{questions.length}</button>
        : <button className="primary wide" disabled={!answered} onClick={()=>{setIdx(i=>i+1);setShowExpl(false)}}>Next Question <ChevronRight/></button>}
    </div>
  </div>;
}

function MockTest({bookmarks,toggleBookmark,onFinish}) {
  const pool=useMemo(()=>MCQS.slice(0,Math.min(10,MCQS.length)),[]);
  const [idx,setIdx]=useState(0), [answers,setAnswers]=useState({}), [seconds,setSeconds]=useState(pool.length*60);
  const [started,setStarted]=useState(false);

  useEffect(()=>{
    if(!started||seconds<=0)return;
    const t=setInterval(()=>setSeconds(s=>s-1),1000);
    return ()=>clearInterval(t);
  },[started,seconds]);

  useEffect(()=>{if(started&&seconds===0)submit()},[seconds,started]);

  const submit=()=>{
    const correct=pool.filter(q=>answers[q.id]===q.correct).length;
    const wrong=pool.filter(q=>answers[q.id]!==undefined&&answers[q.id]!==q.correct).length;
    const score=Math.max(0,correct-wrong*0.25);
    const byDifficulty={Easy:0,Medium:0,Hard:0};
    pool.forEach(q=>byDifficulty[q.difficulty]++);
    onFinish({score:Math.round(score*100)/100,total:pool.length,percent:Math.round(score/pool.length*100),byDifficulty});
  };

  if(!started)return <div className="page narrow enter"><div className="mock-intro"><Trophy size={48}/><h1>VetCEE Full Mock Test</h1><p>10 mixed questions • 1 minute per question • 0.25 negative marking for each wrong answer.</p><div className="mock-rules"><span>⏱ Timed</span><span>🎯 Mixed subjects</span><span>📊 Results saved</span></div><button className="primary" onClick={()=>setStarted(true)}>Start Mock Test</button></div></div>;

  const q=pool[idx], selected=answers[q.id], mm=String(Math.floor(seconds/60)).padStart(2,"0"), ss=String(seconds%60).padStart(2,"0");
  return <div className="page narrow enter">
    <div className="mock-bar"><span><Clock3/> {mm}:{ss}</span><span>Question {idx+1}/{pool.length}</span></div>
    <div className="question-card">
      <span className={`level ${q.difficulty.toLowerCase()}`}>{q.subject.toUpperCase()} • {q.difficulty}</span>
      <h2>{q.question}</h2>
      <div className="options">{q.options.map((opt,i)=><button key={opt} disabled={selected!==undefined} className={selected===i?"option selected":"option"} onClick={()=>setAnswers(a=>({...a,[q.id]:i}))}><span>{String.fromCharCode(65+i)}</span><b>{opt}</b></button>)}</div>
    </div>
    <div className="practice-actions">
      <button className="secondary wide" disabled={idx===0} onClick={()=>setIdx(i=>i-1)}>Previous</button>
      {idx===pool.length-1?<button className="primary wide" onClick={submit}>Submit Test</button>:<button className="primary wide" onClick={()=>setIdx(i=>i+1)}>Next <ChevronRight/></button>}
    </div>
  </div>;
}

function Saved({bookmarks,toggleBookmark}) {
  const saved=MCQS.filter(q=>bookmarks.includes(q.id));
  return <div className="page enter"><div className="page-title"><div><div className="eyebrow">Your collection</div><h1>Saved Questions</h1></div><span className="count-badge">{saved.length}</span></div>
    {!saved.length?<EmptySaved/>:<div className="saved-list">{saved.map(q=><div className="saved-card" key={q.id}><div><span className="pill">{q.subject} • {q.chapter}</span><h3>{q.question}</h3><small>{q.difficulty}</small></div><button onClick={()=>toggleBookmark(q.id)}><Star fill="currentColor"/></button></div>)}</div>}
  </div>;
}

function EmptySaved(){return <div className="empty"><Bookmark size={42}/><h2>No saved questions</h2><p>Tap the star on any question to save it here.</p></div>}

function Notes(){
  const [sub,setSub]=useState("bio");
  return <div className="page enter"><div className="page-title"><div><div className="eyebrow">Quick revision</div><h1>High-Yield Notes</h1></div></div><div className="tabs">{["bio","chem","phys"].map(s=><button className={sub===s?"tab active":"tab"} key={s} onClick={()=>setSub(s)}>{s}</button>)}</div><div className="notes-grid">{NOTES[sub].map((n,i)=><article className="note-card" key={i}><h2>{n.title}</h2><ul>{n.points.map(p=><li key={p}><CheckCircle2/>{p}</li>)}</ul>{n.formula&&<pre>{n.formula}</pre>}{n.trap&&<div className="trap"><Flag/><div><strong>CEE Trap Alert</strong><p>{n.trap}</p></div></div>}</article>)}</div></div>;
}

function Dashboard({stats}){
  const accuracy=stats.attempted?Math.round(stats.correct/stats.attempted*100):0;
  return <div className="page enter"><div className="page-title"><div><div className="eyebrow">Analytics</div><h1>Performance Dashboard</h1></div><RotateCcw size={20}/></div>
    <div className="stats-grid"><Stat label="Questions" value={stats.attempted}/><Stat label="Accuracy" value={`${accuracy}%`}/><Stat label="Best Score" value={`${stats.bestScore||0}%`}/><Stat label="Sessions" value={stats.sessions}/></div>
    <div className="dashboard-grid">
      <section className="panel"><h2>Last 5 sessions</h2>{stats.lastScores.length?<div className="bars">{stats.lastScores.map((s,i)=><div className="bar-col" key={i}><strong>{s}%</strong><div className="bar" style={{height:`${Math.max(8,s)}%`}}/><small>Test {i+1}</small></div>)}</div>:<div className="empty compact">No test data yet.</div>}</section>
      <section className="panel"><h2>Difficulty attempts</h2>{["Easy","Medium","Hard"].map(d=><div className="meter-row" key={d}><span>{d}</span><div><i style={{width:`${Math.min(100,stats.byDifficulty[d]*10)}%`}}/></div><b>{stats.byDifficulty[d]||0}</b></div>)}</section>
    </div>
    <section className="trust-card"><ShieldCheck/><div><strong>Study smart, not just hard.</strong><p>Use chapter practice to identify weak areas, then retake mixed mock tests regularly.</p></div></section>
  </div>;
}

function Stat({label,value}){return <div className="stat"><strong>{value}</strong><small>{label}</small></div>}
function Empty({chapter,reset}){return <div className="empty page"><PenTool size={44}/><h2>No questions found</h2><p>No questions are currently available for {chapter||"this filter"}.</p><button className="primary" onClick={reset}>Show All Difficulties</button></div>}

export default App;
